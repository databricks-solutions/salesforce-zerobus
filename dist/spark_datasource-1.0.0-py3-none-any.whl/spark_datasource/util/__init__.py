"""
Utility modules for Spark Data Source.
"""

from .ChangeEventHeaderUtility import process_bitmap

__all__ = ['process_bitmap']
